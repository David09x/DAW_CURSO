import java.util.ArrayList;
import java.util.Scanner;

public class Partida {

    Numeros[] ruleta = new Numeros[37];
    ArrayList<Jugador> jugadores = new ArrayList<>();
    ArrayList<Apuesta> apuestas = new ArrayList<>();

    public void  main(){
        crear_ruleta();
        crear_jugadores();
        hagan_susApuestas();

    }

    private void hagan_susApuestas() {
        int opcion;
        Integer numero;
        int apuesta;
        String color;
        String parImpar;
        Apuesta apuestaAux = new Apuesta();
        Scanner scan = new Scanner(System.in);

        for (Jugador j:jugadores) {
            System.out.println("1 para apostar a número");
            System.out.println("2 para apostar a color");
            System.out.println("3 para apostar a par/impar");
            opcion = scan.nextInt();
            switch (opcion) {
                case 1:
                    System.out.println("Numero del 0-36 al que quiere apostar");
                    numero = scan.nextInt();
                    apuestaAux.setTipo(opcion);
                    apuestaAux.setValor(numero.toString());
                    break;
                case 2:
                    System.out.println("A que color quiere apostar Negro/Rojo");
                    color = scan.nextLine();
                    apuestaAux.setTipo(opcion);
                    apuestaAux.setValor(color);
                    break;
                case 3:
                    System.out.println("Seleccione par/impar");
                    parImpar = scan.nextLine();
                    apuestaAux.setTipo(opcion);
                    apuestaAux.setValor(parImpar);
                    break;
                default:
            }
            do {
                System.out.println("Cuanto dinero quiere apostar?");
                apuesta = scan.nextInt();
                apuestaAux.setCantidad(apuesta);
            }while(apuesta>j.getDinero() || apuesta<=0);
            apuestas.add(apuestaAux);
        }


    }

    private void crear_jugadores() {
        String nombre = "";
        int saldo = 0;
        Scanner scan = new Scanner(System.in);

        System.out.println("Cuantos jugaran?");
        int numJugadores = scan.nextInt();
        for (int i = 0; i < numJugadores; i++) {
            System.out.println("Nombre del jugador " + i+1 );
            nombre = scan.nextLine();
            System.out.println("Saldo del jugador " + i+1 );
            saldo = scan.nextInt();
            jugadores.add(new Jugador(nombre,saldo));
        }
    }

    private void crear_ruleta() {
        for (int i = 0; i < ruleta.length; i++) {
            ruleta[i] = new Numeros(i);
        }
    }


}
